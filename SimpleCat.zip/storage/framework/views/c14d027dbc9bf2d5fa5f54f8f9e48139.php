<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>

  <title><?php echo e($title ?? 'Simple Cat'); ?></title>
  <link rel="icon" href="<?php echo e(asset('img/Logo-Simple-Cat.svg')); ?>" type="image/x-icon">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="bg-slate-200 dark:bg-slate-700">
  
  
  <main data-scroll-container>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('partials.navbar');

$__html = app('livewire')->mount($__name, $__params, 'lw-1681456232-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('partials.cart');

$__html = app('livewire')->mount($__name, $__params, 'lw-1681456232-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php echo e($slot); ?>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('partials.newsletter');

$__html = app('livewire')->mount($__name, $__params, 'lw-1681456232-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('partials.footer');

$__html = app('livewire')->mount($__name, $__params, 'lw-1681456232-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
  </main>
  <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

  <script src="https://kit.fontawesome.com/0f25473561.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

  <?php echo app('Illuminate\Foundation\Vite')('resources/js/swiper.js'); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</body>

</html><?php /**PATH C:\Users\amani\OneDrive\Área de Trabalho\E-commerce Simple Cat\SimpleCat\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>