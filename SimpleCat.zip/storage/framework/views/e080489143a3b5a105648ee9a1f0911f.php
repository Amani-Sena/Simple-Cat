<div class="cart-bg" id="cart-bg">
<div class="cart">
    <div class="cart-title">    
        <div class="X-button" id="close-cart">
            <div class="X-button-item-1"></div>
            <div class="X-button-item-2"></div>
        </div>
        <h4>Sua sacola</h4>
    </div>
    <div class="cart-product-container">

    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="cart-product" wire:key='<?php echo e($item['product_id']); ?>'>
            <div class="cart-product-img">
                <img src="<?php echo e(url('storage', $item['image'])); ?>" alt="<?php echo e($item['name']); ?>">
            </div>
            <div class="cart-product-info">
                <div class="cart-product-info-list">
                    <h6><?php echo e($item['name']); ?></h6>
                    <p class="p-small-gray">Tamanho: M</p>
                    <p class="p-small-gray">Cor: Branca</p>
                    <div class="cart-product-price">
                        <select wire:model.live="quantity<?php echo e($item['product_id']); ?>" wire:target="addToCart(<?php echo e($item['product_id']); ?>" wire:change="addToCart(<?php echo e($item['product_id']); ?> ,$event.target.value)" name="units" id="units" class="btn-select">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = range(1, 10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!--[if BLOCK]><![endif]--><?php if($item['quantity']  == $quant): ?>
                                    <option value="<?php echo e($item['quantity']); ?>" selected><?php echo e($item['quantity']); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($quant); ?>"><?php echo e($quant); ?></option>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                        <h6 class="gray"><?php echo e(Number::currency($item['total_amount'], 'BRL')); ?></h6>
                    </div>
                    
                </div>
                <div class="cart-product-trash">
                    <a href="#" wire:click.prevent='removeItem(<?php echo e($item['product_id']); ?>)'><i class="fa-solid fa-trash"></i></a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h4>Sacola vazia.</h4>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
    <div class="cart-checkout">
        <div class="cart-total">
            <span class="p-medium-gray">Subtotal: <?php echo e(Number::currency($grand_total, 'BRL')); ?></span>
            <span class="p-medium-gray">Frete: <?php echo e(Number::currency(0, 'BRL')); ?></span>
            <span class="p-medium-gray">Total: <?php echo e(Number::currency($grand_total, 'BRL')); ?></span>
        </div>
        <!--[if BLOCK]><![endif]--><?php if($cart_items): ?>
        <a href="/checkout" class="btn-default">Finalizar compra</a>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    
</div>
</div><?php /**PATH C:\Users\amani\OneDrive\Área de Trabalho\E-commerce Simple Cat\SimpleCat\resources\views/livewire/partials/cart.blade.php ENDPATH**/ ?>