<section id="section-newsletter" data-scroll-section>
    <div class="title-section-newsletter">
      <h4>Receba nossas ofertas e promoções exclusivas!</h4>
      <p class="p-medium-gray">Fique tranquilo! Somos totalmente contra spam.</p>
    </div>

    <form action="">
      <input type="text" placeholder="Seu nome">
      <input type="text" placeholder="Seu email">
      <button>Enviar</button>
    </form>
  </section><?php /**PATH C:\Users\amani\OneDrive\Área de Trabalho\E-commerce Simple Cat\SimpleCat\resources\views/livewire/partials/newsletter.blade.php ENDPATH**/ ?>