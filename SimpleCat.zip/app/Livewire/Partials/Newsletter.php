<?php

namespace App\Livewire\Partials;

use Livewire\Component;

class Newsletter extends Component
{
    public function render()
    {
        return view('livewire.partials.newsletter');
    }
}