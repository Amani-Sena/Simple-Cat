<section id="section-cancel">
    <div class="cancel-container">
        <h3>Pagamento não realizado, <br> pedido cancelado! :(</h3>
        <div class="cancel-buttons">
            <a href="" class="btn-default">Voltar para a loja</a>
            <a href="" class="btn-default">Ver meus pedidos</a>
        </div>
    </div>
    
</section>